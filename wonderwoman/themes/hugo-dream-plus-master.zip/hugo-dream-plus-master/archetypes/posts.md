---
title: {{ replace .TranslationBaseName "-" " " | title }}
date: {{ .Date }}
lastmod: {{ .Date }}
cover: "/images/default1.jpg"
draft: true
categories: ["category1"]
tags: ["tag1", "tag2"]
description:
---
